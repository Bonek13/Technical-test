from odoo import api, fields, models
 
class MasterRuangan(models.Model):
    _name = 'master.ruangan'
    _description = 'Technical test'
     
    name = fields.Char(string='Nama Ruangan', required=True)
    type_room = fields.Selection([
            ('meeting_room_kecil', 'Meeting Room Kecil'),
            ('meeting_room_besar', 'Meeting Room Besar'),
            ('aula', 'Aula'),
            ], string='Tipe Ruangan', required=True)
    location_room = fields.Selection([
            ('1a', '1A'),
            ('1b', '1B'),
            ('1c', '1C'),
            ('2a', '2A'),
            ('2b', '2B'),
            ('2c', '2C'),
            ], string='Lokasi Ruangan', required=True)
    capacity_room = fields.Char(string='Kapasitas Ruangan', required=True)                
    description = fields.Text(string='Keterangan')
    image = fields.Image(string="Image")

    _sql_constraints = [
        ('nama_ruangan_unik', 'UNIQUE(name)', 'Nama ruangan tidak boleh sama ')
    ]
