from odoo import api, fields, models
from odoo.exceptions import ValidationError

class PemesananRuangan(models.Model):
    _name = 'pemesanan.ruangan'

    number = fields.Char(string='Nomor Pemesanan', readonly=True, default='New') 
    name = fields.Char(string='Nama Pemesan', required=True)
    date = fields.Date(string='Tanggal Pemesanan')
    desc = fields.Text(string='Catatan Pemesanan')
    state = fields.Selection([('draft', 'Draft'), ('ongoing', 'OnGoing'), ('done', 'Done')], string='Status', readonly=True, default='draft')
 

    _sql_constraints = [
        ('nama_pemesan_unik', 'UNIQUE(name)', 'Nama pemesan tidak boleh sama ')
    ]

    def action_confirm(self):
        self.write({'state': 'ongoing'})
      
    def action_cancel(self):
        self.write({'state': 'draft'})
      
    def action_close(self):
        self.write({'state': 'done'})




@api.model
def create(self, vals):
    vals['number'] = self.env['ir.sequence'].next_by_code('pemesanan.ruangan')
    return super(Pemesanan, self).create(vals)