# -*- coding: utf-8 -*-
{
    'name': "Pemesanan Ruangan",

    'summary': """ Modul untuk technical Odoo """,

    'description': """
        Modul ini berfungsi untuk menjalankan technical documentation.
    """,


    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        'views/master_ruangan_views.xml',
        'views/pemesanan_views.xml',
        'views/menuitem.xml',
        'views/ir_sequence_data.xml',
        #'views/templates.xml',
    ],
    # only loaded in demonstration mode
    #'demo': [
        #'demo/demo.xml',
    #],
    
    'application': True,
    'installable': True,
}